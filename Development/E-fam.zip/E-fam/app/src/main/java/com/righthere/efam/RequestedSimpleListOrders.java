package com.righthere.efam;

public class RequestedSimpleListOrders {
	String item_id;
	String item_ref_number;
	String item_status;
	String item_customer_order;
	String item_one;
	String item_two;
	String item_outlet;
	String item_outletid;
	String item_branchid;
	String item_brandid;
	String item_three;
	String item_customer_name;
	String item_customer_email;
	String item_customer_address;
	String item_four;
	String item_five;
	String item_customer_deliveryfee;
	String item_customer_servicefee;
	String item_rate;

	public void setItemId(String item_id) {
		this.item_id = item_id;
	}

	public String getItemId() {
		return item_id;
	}

	public void setItemRefNumber(String item_ref_number) {
		this.item_ref_number = item_ref_number;
	}

	public String getItemRefNumber() {
		return item_ref_number;
	}

	public void setCustomerOrder(String item_customer_order) {
		this.item_customer_order = item_customer_order;
	}

	public String getCustomerOrder() {
		return item_customer_order;
	}

	public void setItemStatus(String item_status) {
		this.item_status = item_status;
	}

	public String getItemStatus() {
		return item_status;
	}

	public void setItemOne(String item_one) {
		this.item_one = item_one;
	}

	public String getItemOne() {
		return item_one;
	}

	public void setItemTwo(String item_two) {
		this.item_two = item_two;
	}

	public String getItemTwo() {
		return item_two;
	}

	public void setItemOutlet(String item_outlet) {
		this.item_outlet = item_outlet;
	}

	public String getItemOutlet() {
		return item_outlet;
	}

	public void setItemBrandId(String item_brandid) {
		this.item_brandid = item_brandid;
	}

	public String getItemBrandId() {
		return item_brandid;
	}

	public void setItemBranchid(String item_branchid) {
		this.item_branchid = item_branchid;
	}

	public String getItemBranchId() {
		return item_branchid;
	}

	public void setItemThree(String item_three) {
		this.item_three = item_three;
	}

	public String getItemThree() {
		return item_three;
	}

	public void setItemFour(String item_four) {
		this.item_four = item_four;
	}

	public String getItemFour() {
		return item_four;
	}

	public void setItemFive(String item_five) {
		this.item_five = item_five;
	}

	public String getItemfive() {
		return item_five;
	}

	public void setCustomerName(String item_customer_name) {
		this.item_customer_name = item_customer_name;
	}

	public String getCustomerName() {
		return item_customer_name;
	}

	public void setCustomerEmail(String item_customer_email) {
		this.item_customer_email = item_customer_email;
	}

	public String getCustomerEmail() {
		return item_customer_email;
	}

	public void setCustomerAddress(String item_customer_address) {
		this.item_customer_address = item_customer_address;
	}

	public String getCustomerAddress() {
		return item_customer_address;
	}

	public void setCustomerservicefee(String item_customer_servicefee) {
		// TODO Auto-generated method stub
		this.item_customer_servicefee = item_customer_servicefee;
	}

	public String getCustomerservicefee() {
		return item_customer_servicefee;
	}

	public void setCustomerdeliveryfee(String item_customer_deliveryfee) {
		// TODO Auto-generated method stub
		this.item_customer_deliveryfee = item_customer_deliveryfee;
	}

	public String getCustomerdeliveryfee() {
		return item_customer_deliveryfee;
	}

	public void setItemRate(String item_rate) {
		this.item_rate = item_rate;
	}

	public String getItemRate() {
		return item_rate;
	}

}
