package com.righthere.efam.image_details;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.righthere.efam.ImageDownloader;
import com.righthere.efam.R;
import com.righthere.efam.preference.PrefManager;

/**
 * Created by muragewanjohi on 19/11/2016.
 */

public class DialogImageDetails extends DialogFragment {

    private PrefManager prefManager;
    private ViewPager viewPager;
    private LinearLayout dotsLayout;
    private TextView[] dots;
    private int[] layouts;
    private Button btnSkip, btnNext;
    private Context context;

    ImageDownloader imageDownloader;

    public DialogImageDetails() {
        // Empty constructor is required for DialogFragment
        // Make sure not to add arguments to the constructor
        // Use `newInstance` instead as shown below
    }

    public static DialogImageDetails newInstance(String title) {
        DialogImageDetails frag = new DialogImageDetails();
        Bundle args = new Bundle();
        args.putString("title", title);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.image_details, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        prefManager = new PrefManager(getContext());

        imageDownloader = new ImageDownloader();

        viewPager = new ViewPager(getActivity());

        viewPager.setId( R.id.view_pager);

        viewPager.setAdapter(new MyPagerAdapter(getFragmentManager()));

        getDialog().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

/*    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.image_details_dialog, container, false);

        prefManager = new PrefManager(getContext());

        imageDownloader = new ImageDownloader();

        viewPager = (ViewPager) rootView.findViewById(R.id.viewPager);
        viewPager.setAdapter(new MyPagerAdapter(getFragmentManager()));

        return rootView;
    }*/

    private class MyPagerAdapter extends FragmentPagerAdapter {

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int pos) {
            switch(pos) {

                case 0: return FragmentTop.newInstance("FragmentTop, Instance 1");
                case 1: return FragmentFront.newInstance("FragmentFront, Instance 1");
                case 2: return FragmentBack.newInstance("FragmentBack, Instance 1");
                case 3: return FragmentBack.newInstance("FragmentBack, Instance 2");
                case 4: return FragmentBack.newInstance("FragmentBack, Instance 3");
                default: return FragmentBack.newInstance("FragmentBack, Default");
            }
        }

        @Override
        public int getCount() {
            return 5;
        }
    }
}
