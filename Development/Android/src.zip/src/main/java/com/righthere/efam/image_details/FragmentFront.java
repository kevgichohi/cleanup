package com.righthere.efam.image_details;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.righthere.efam.ImageDownloader;
import com.righthere.efam.R;
import com.righthere.efam.preference.PrefManager;

/**
 * Created by muragewanjohi on 19/11/2016.
 */

public class FragmentFront extends Fragment {

    ImageDownloader imageDownloader;
    private PrefManager prefManager;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View rootView = inflater.inflate(R.layout.image_details_front, container, false);

        prefManager = new PrefManager(getContext());

        imageDownloader = new ImageDownloader();

        ImageView ivPreview = (ImageView)rootView.findViewById(R.id.image_front);

        imageDownloader.download(prefManager.getFRONT_IMAGE(), ivPreview);

        Log.d("image_details_front", " --> " + prefManager.getFRONT_IMAGE());;

        TextView tv_description = (TextView)rootView.findViewById(R.id.txt_description);

        tv_description.setText(prefManager.getDescription());

        Log.d("getDescription() ", " --> " + prefManager.getDescription());

        return rootView;
    }
    public static FragmentFront newInstance(String text) {

        FragmentFront f = new FragmentFront();
        Bundle b = new Bundle();
        b.putString("msg", text);

        f.setArguments(b);

        return f;
    }
}