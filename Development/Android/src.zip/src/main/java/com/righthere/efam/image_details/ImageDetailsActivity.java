package com.righthere.efam.image_details;

/**
 * Created by muragewanjohi on 19/11/2016.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;

import com.righthere.efam.R;

public class ImageDetailsActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_details_dialog);

        ViewPager pager = (ViewPager) findViewById(R.id.viewPager);
        pager.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));
    }

    private class MyPagerAdapter extends FragmentPagerAdapter {

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int pos) {
            switch(pos) {

                case 0: return FragmentFront.newInstance("FragmentFront, Instance 1");
                case 1: return FragmentBack.newInstance("FragmentBack, Instance 2");
                case 2: return FragmentTop.newInstance("FragmentTop, Instance 3");
                default: return FragmentFront.newInstance("FragmentFront, Default");
            }
        }

        @Override
        public int getCount() {
            return 3;
        }
    }
}
