package com.righthere.efam.image_details;

/**
 * Created by muragewanjohi on 19/11/2016.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.righthere.efam.ImageDownloader;
import com.righthere.efam.R;
import com.righthere.efam.preference.PrefManager;

public class FragmentBack extends Fragment {

    ImageDownloader imageDownloader;
    private PrefManager prefManager;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.image_details_back, container, false);

        prefManager = new PrefManager(getContext());

        imageDownloader = new ImageDownloader();

        ImageView ivPreview = (ImageView)rootView.findViewById(R.id.image_back);

        imageDownloader.download(prefManager.getBACK_IMAGE(), ivPreview);

        Log.d("image_dialog_top", " --> " + prefManager.getBACK_IMAGE());
        return rootView;
    }

    public static FragmentBack newInstance(String text) {

        FragmentBack f = new FragmentBack();
        Bundle b = new Bundle();
        b.putString("msg", text);

        f.setArguments(b);

        return f;
    }
}