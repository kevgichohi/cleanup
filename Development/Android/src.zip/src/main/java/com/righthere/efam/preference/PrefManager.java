package com.righthere.efam.preference;

/**
 * Created by Wanjohi on 8/23/2016.
 */
import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;

    private static final String TOP_IMAGE = "top_image";
    private static final String FRONT_IMAGE = "front_image";
    private static final String BACK_IMAGE = "back_image";
    private static final String DESCRIPTION = "description";


    // shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences file name
    private static final String PREF_NAME = "E-fam";

    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";

    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void setTOP_IMAGE(String image){
        editor.putString(TOP_IMAGE, image);
        editor.commit();
    }
    public String getTOP_IMAGE(){
        return pref.getString(TOP_IMAGE,TOP_IMAGE);
    }
    public void setFRONT_IMAGE(String image){
        editor.putString(FRONT_IMAGE, image);
        editor.commit();
    }
    public String getFRONT_IMAGE(){
        return pref.getString(FRONT_IMAGE,FRONT_IMAGE);
    }
    public void setBACK_IMAGE(String image){
        editor.putString(BACK_IMAGE, image);
        editor.commit();
    }
    public String getBACK_IMAGE(){
        return pref.getString(BACK_IMAGE,BACK_IMAGE);
    }

    public void setDescription(String description){
        editor.putString(DESCRIPTION, description);
        editor.commit();
    }
    public String getDescription(){
        return pref.getString(DESCRIPTION,DESCRIPTION);
    }
}