package com.righthere.efam.interfaces;

/**
 * Created by Wanjohi on 9/14/2016.
 *
 * Global values that can be accessed from all classes
 */
public interface Constants {

    public static final String IMAGES_URL = "http://e-fam.com/inventorymanager/app/webroot/img/uploads/";
    public static final String COMPANY_TOKEN = "AC6BEE13-2DDD-4777-B904-541F3D013858";
    public static final String SERVICE_TYPE = "5618";

}
