package com.righthere.efam;

import java.io.File;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.Tracker;
import com.google.gson.Gson;

import com.righthere.efam.AnimatedGifImageView;
import com.righthere.efam.AnimatedGifImageView.TYPE;
import com.righthere.efam.analytics.AnalyticsApplication;
import com.righthere.efam.interfaces.Constants;

public class ActivityStep07ListProducts extends FragmentActivity {
	SQLiteDatabase nunuaRahaDatabase;
	public static final String MY_SESSION = "mySession";
	SharedPreferences sharedPreferences;
	SharedPreferences.Editor editor;
	Gson gson;

	ArrayList<RequestedResults> PRODUCTSBRANDSLIST;
	AdapterProducts myadapter;

	LinearLayout layout_progressbar;
	RelativeLayout headersection;
	RelativeLayout centerwrap;
	RelativeLayout footersection;
	LinearLayout listViewCont;
	ListView listView;
	public static String SELECTED_PRODUCT_ID;
	public static String SELECTED_PRODUCT_TITLE;
	public static String SELECTED_AISLE_ID;
	public static String SELECTED_AISLE_TITLE;
	public static String SELECTED_BRANCH_ID;
	public static String SELECTED_BRANCH_TITLE;
	public static String SELECTED_BRAND_ID;
	public static String SELECTED_BRAND_TITLE;
	public static String SELECTED_BRAND_LOGO;
	public static String SELECTED_LOCATION_ID;
	public static String SELECTED_LOCATION_TITLE;
	public static String SELECTED_OUTLET_ID;
	public static String SELECTED_OUTLET_TITLE;
	public static String PREVGOODSLISTID;
	public static String PREVGOODSLISTTITLE;
	public static String NEXTGOODSLISTID;
	public static String NEXTGOODSLISTTITLE;
	public static Integer CURRENT_GOODS_LIST_ID_POSITION;
	public static Integer PREV_GOODS_LIST_ID_POSITION;
	public static Integer NEXT_GOODS_LIST_ID_POSITION;
	public static Integer CURRENT_AISLE_ID_POSITION;
	Typeface EkMukta_Light;
	TextView app_name;
	TextView headerText;
	Button menuIcon;
	Button shoppingButton;
	Button cartButton;
	TextView cartButtonNotification;
	TextView ItemperPrice;
	Button backToAisles;
	Button backToCategory;
	TextView aisleTitle;
	ImageView shopLogoview;
	String extStorageDirectory;
	Bitmap bm;

	Button proceedToCheckout;
	Button clearcart;

    private Tracker mTracker;

    FragmentManager fm;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.scroller_products);
		overridePendingTransition(R.anim.slide_page_in, R.anim.slide_page_out);// SlideIn
																				// animation
		initViews();

        AnalyticsApplication application = (AnalyticsApplication) getApplication();
        mTracker = application.getDefaultTracker();
        Log.i("Activity: ", "Activity: " + "List Products");
        mTracker.setScreenName("Activity" + "List Products");
        mTracker.send(new HitBuilders.ScreenViewBuilder().build());

		// LIST VIEW
		new retrieveFromDBTask().execute();
		PRODUCTSBRANDSLIST = new ArrayList<RequestedResults>();
        fm = getSupportFragmentManager();
        myadapter = new AdapterProducts(ActivityStep07ListProducts.this,
                PRODUCTSBRANDSLIST, cartButtonNotification, layout_progressbar,fm);
		listView.setAdapter(myadapter);
		myadapter.notifyDataSetChanged();

	}

	private void initViews() {

        Log.d("list_of_products","list_of_products");

        extStorageDirectory = Environment.getExternalStorageState().toString();
		extStorageDirectory = Environment.getExternalStorageDirectory()
				.toString();

		nunuaRahaDatabase = openOrCreateDatabase("nunuaRahaDatabase",
				MODE_PRIVATE, null);
		listView = (ListView) findViewById(R.id.productsListView);
		layout_progressbar = (LinearLayout) findViewById(R.id.progressbar_view);
		headersection = (RelativeLayout) findViewById(R.id.header);
		footersection = (RelativeLayout) findViewById(R.id.footer);
		listViewCont = (LinearLayout) findViewById(R.id.listViewCont);
		sharedPreferences = getSharedPreferences(MY_SESSION,
				Context.MODE_PRIVATE);
		editor = sharedPreferences.edit();
		gson = new Gson();
		EkMukta_Light = Typeface.createFromAsset(getAssets(),
				"fonts/ek_mukta/EkMukta-Light.ttf");
		app_name = (TextView) findViewById(R.id.app_name);
		headerText = (TextView) findViewById(R.id.headerText);
		menuIcon = (Button) findViewById(R.id.menu_icon);
		shoppingButton = (Button) findViewById(R.id.shoppingButton);
		cartButton = (Button) findViewById(R.id.cartButton);
		cartButtonNotification = (TextView) findViewById(R.id.cartButtonNotification);
		backToAisles = (Button) findViewById(R.id.backToAisles);
		backToCategory = (Button) findViewById(R.id.backButton);
		proceedToCheckout = (Button) findViewById(R.id.proceedToCheckout);
		aisleTitle = (TextView) findViewById(R.id.aisleTitle);
		// shopLogoview = (ImageView) findViewById(R.id.shopLogo);

		proceedToCheckout = (Button) findViewById(R.id.proceedToCheckout);
		clearcart = (Button) findViewById(R.id.clearcart);

		SELECTED_OUTLET_ID = sharedPreferences.getString("selectedOutletId",
				null);
		SELECTED_OUTLET_TITLE = sharedPreferences.getString("selectedOutlet",
				null);
		SELECTED_LOCATION_ID = sharedPreferences.getString(
				"selectedLocationId", null);
		SELECTED_LOCATION_TITLE = sharedPreferences.getString(
				"selectedLocation", null);
		SELECTED_BRAND_ID = sharedPreferences
				.getString("selectedBrandId", null);
		SELECTED_BRAND_TITLE = sharedPreferences.getString("selectedBrand",
				null);
		SELECTED_BRAND_LOGO = sharedPreferences.getString("selectedBrandLogo",
				null);
		SELECTED_BRANCH_ID = sharedPreferences.getString("selectedBranchId",
				null);
		SELECTED_BRANCH_TITLE = sharedPreferences.getString("selectedBranch",
				null);
		SELECTED_AISLE_ID = sharedPreferences
				.getString("selectedAisleId", null);
		SELECTED_AISLE_TITLE = sharedPreferences.getString("selectedAisle",
				null);
		Bundle extras = getIntent().getExtras();
		SELECTED_PRODUCT_ID = extras.getString("selectedProductId");
		SELECTED_PRODUCT_TITLE = extras.getString("selectedProductTitle");
		app_name.setTypeface(EkMukta_Light);
		headerText.setText(SELECTED_BRANCH_TITLE);
		aisleTitle.setText(SELECTED_AISLE_TITLE + " : "
				+ SELECTED_PRODUCT_TITLE);

		// backToCategory.setText("Back to "+SELECTED_AISLE_TITLE);

		ImageView headerTextimage2 = (ImageView) findViewById(R.id.headerTextimage);
		headerTextimage2.setVisibility(View.VISIBLE);
		headerTextimage2.setImageResource(R.mipmap.superheading1);

		// LOAD QUICKLINKS
		HelperQuickLinks helperQuickLinks = new HelperQuickLinks();
		helperQuickLinks.create(menuIcon, shoppingButton, cartButton,
				cartButtonNotification, ActivityStep07ListProducts.this,
				sharedPreferences);

		clearcart.setVisibility(View.VISIBLE);
		clearcart.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				if (sharedPreferences.contains("myTrolley")) {
					try {
						showDialogEmptyTrolley("Are you sure?");
					} catch (Exception e) {
						e.printStackTrace();
					}

				} else {
					Toast.makeText(ActivityStep07ListProducts.this,
							"No items in your cart to clear!",
							Toast.LENGTH_LONG).show();
				}

			}
		});

		proceedToCheckout.setVisibility(View.VISIBLE);
		proceedToCheckout.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// Intent intent = new Intent(ActivityMyAccountAddresses.this,
				// ActivityStep09ListCart.class);
				// startActivity(intent);
				if (sharedPreferences.contains("myTrolley")) {
					// Intent intent = new
					// Intent(ActivityMyAccountAddresses.this,
					// ActivityStep09ListDeliveryOptions.class);
					// startActivity(intent);
					Toast.makeText(ActivityStep07ListProducts.this,
							"click your cart to confirm first",
							Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(ActivityStep07ListProducts.this,
							"No items in your cart !", Toast.LENGTH_LONG)
							.show();
				}
			}
		});

		footersection.setVisibility(View.VISIBLE);
		backToCategory.setVisibility(View.VISIBLE);
		// backToAisles.setVisibility(View.VISIBLE);

		backToCategory.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(ActivityStep07ListProducts.this,
						ActivityStep05ListAisles.class);
				startActivity(intent);
			}
		});

		backToAisles.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				finish();
			}
		});

		/*
		 * proceedToCheckout.setOnClickListener(new View.OnClickListener() {
		 * public void onClick(View v) { Intent intent = new
		 * Intent(ActivityStep07ListProducts.this,
		 * ActivityStep08ListCart.class); startActivity(intent); } });
		 */

	}

	@Override
	public void onBackPressed() {
		finish();
		overridePendingTransition(R.anim.slide_page_in, R.anim.slide_page_out);// SlideIn
																				// animation
	}

	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.slide_page_in, R.anim.slide_page_out);// SlideIn
																				// animation
	}

	@Override
	public void onResume() {
		super.onResume(); // Always call the superclass method first
		overridePendingTransition(R.anim.slide_page_in, R.anim.slide_page_out);// SlideIn
																				// animation

        myadapter = new AdapterProducts(ActivityStep07ListProducts.this,
                PRODUCTSBRANDSLIST, cartButtonNotification, layout_progressbar,fm);
		listView.setAdapter(myadapter);
		myadapter.notifyDataSetChanged();

		// LOAD QUICKLINKS
		HelperQuickLinks helperQuickLinks = new HelperQuickLinks();
		helperQuickLinks.create(menuIcon, shoppingButton, cartButton,
				cartButtonNotification, ActivityStep07ListProducts.this,
				sharedPreferences);
	}

	private class retrieveFromDBTask extends AsyncTask<String, Void, String> {

		@Override
		protected void onPreExecute() {
			layout_progressbar.setVisibility(View.VISIBLE);

			AnimatedGifImageView animatedGifImageView = ((AnimatedGifImageView) findViewById(R.id.animatedGifImageView));
			animatedGifImageView.setAnimatedGif(R.mipmap.loading_bar,
					TYPE.FIT_CENTER);

			listView.setVisibility(View.GONE);
			super.onPreExecute();
		}

		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			return "Done";
		}

		protected void onPostExecute(String params) {

			layout_progressbar.setVisibility(View.GONE);
			listView.setVisibility(View.VISIBLE);
			myadapter.notifyDataSetChanged();
			// super.onPostExecute();
			JSONObject jsonMyCartObject = null;
			if (sharedPreferences.contains("myTrolley")) {
				String jsonMyCartString = sharedPreferences.getString(
						"myTrolley", null);
				try {
					jsonMyCartObject = new JSONObject(jsonMyCartString);
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			Cursor resultsStockCursor = nunuaRahaDatabase.rawQuery(
					"SELECT * FROM hdjgf_shops_stocks WHERE branch_id = "
							+ SELECTED_BRANCH_ID + " AND aisle_id = "
							+ SELECTED_AISLE_ID + " AND product_id = "
							+ SELECTED_PRODUCT_ID, null);
			resultsStockCursor.moveToFirst();
			String stock_id = resultsStockCursor.getString(0);

			Cursor resultsProductsCursor = nunuaRahaDatabase.rawQuery(
					"SELECT * FROM hdjgf_shops_stocks_brands WHERE stock_id = "
							+ stock_id, null);
			resultsProductsCursor.moveToFirst();
			String[] list_item_ids = new String[resultsProductsCursor
					.getCount()];
			String[] list_item_titles = new String[resultsProductsCursor
					.getCount()];

			Log.d("SELECTED_PRODUCT_TITLE ",SELECTED_PRODUCT_TITLE);

			int k = 0;
			while (resultsProductsCursor.isAfterLast() == false) {
				String item_id = resultsProductsCursor.getString(0);
				String item_title = resultsProductsCursor.getString(1);
				String item_size = resultsProductsCursor.getString(2);
				String item_price = resultsProductsCursor.getString(3);
				String item_thumbnail_url = resultsProductsCursor.getString(4);
				String item_front_thumbnail_url = resultsProductsCursor.getString(4);
				String item_back_thumbnail_url = resultsProductsCursor.getString(5);
				String item__top_thumbnail_url = resultsProductsCursor.getString(6);
				String item__description = resultsProductsCursor.getString(7);

				Integer item_units_in_cart = 0;
				if (jsonMyCartObject != null) {
					try {
						item_units_in_cart = Integer.parseInt(jsonMyCartObject
								.getString(item_id));
					} catch (NumberFormatException | JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				list_item_ids[k] = item_id;
				list_item_titles[k] = item_title;

				RequestedResults d = new RequestedResults();

				if(SELECTED_PRODUCT_TITLE.equals("Bread")){
                    item_thumbnail_url = "bread_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Cake")){
                    item_thumbnail_url = "cake_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Eggs")){
                    item_thumbnail_url = "eggs_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Milk")){
                    item_thumbnail_url = "milk_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Yoghurt")){
                    item_thumbnail_url = "milk_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Tea")){
                    item_thumbnail_url = "tea_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Cocoa")){
                    item_thumbnail_url = "cocoa_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Coffee")){
                    item_thumbnail_url = "coffee_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Fresh Juice")){
                    item_thumbnail_url = "fresh_juice_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Concentrated Juice")){
                    item_thumbnail_url = "concentrated_juice_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Water")){
                    item_thumbnail_url = "water_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Softdrinks")){
                    item_thumbnail_url = "soft_drinks_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Energy Drinks")){
                    item_thumbnail_url = "energy_drink_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Ready To Drink")){
                    item_thumbnail_url = "ready_to_drink_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Powdered Juice")){
                    item_thumbnail_url = "powdered_juice_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Malt Drink")){
                    item_thumbnail_url = "malt_drink_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Soya Drink")){
                    item_thumbnail_url = "soya_drink_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Aperitif")){
                    item_thumbnail_url = "alcohol_aperitif_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Beer")){
                    item_thumbnail_url = "alcohol_beer_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Brandy")){
                    item_thumbnail_url = "alcohol_brandy_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Cider")){
                    item_thumbnail_url = "alcohol_cider_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Cognac")){
                    item_thumbnail_url = "alcohol_cognac_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Gin")){
                    item_thumbnail_url = "alcohol_gin_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Liquer")){
                    item_thumbnail_url = "alcohol_liquer_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Bitter Sweet")){
                    item_thumbnail_url = "alcohol_bitter_sweet_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Rtd")){
                    item_thumbnail_url = "alcohol_rtd_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Rum")){
                    item_thumbnail_url = "alcohol_rum_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Tequila")){
                    item_thumbnail_url = "alcohol_tequila_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Vodka")){
                    item_thumbnail_url = "alcohol_vodka_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Whisky")){
                    item_thumbnail_url = "alcohol_whiskey_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Alcohol Wine")){
                    item_thumbnail_url = "alcohol_wine_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Maize Meal Ugali")){
                    item_thumbnail_url = "maized_meal_ugali_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Wheat Flour")){
                    item_thumbnail_url = "wheat_flour_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Porridge Flour")){
                    item_thumbnail_url = "porridge_flour";
                }else if(SELECTED_PRODUCT_TITLE.equals("Custard Powder")){
                    item_thumbnail_url = "custard_powder_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baking Powder")){
                    item_thumbnail_url = "baking_powder_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Yeast")){
                    item_thumbnail_url = "yeast_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Fruits")){
                    item_thumbnail_url = "fruits_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baby Food")){
                    item_thumbnail_url = "baby_food_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baby Diapers")){
                    item_thumbnail_url = "baby_diapers_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baby Wipes")){
                    item_thumbnail_url = "baby_wipes_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baby Soap")){
                    item_thumbnail_url = "baby_soap_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baby Lotions")){
                    item_thumbnail_url = "baby_lotion_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Baby Powder")){
                    item_thumbnail_url = "baby_powder_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Baby Jelly")){
					item_thumbnail_url = "baby_jelly_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Beef")){
                    item_thumbnail_url = "beef_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Vegetables")){
                    item_thumbnail_url = "vegetables_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Chicken")){
                    item_thumbnail_url = "chicken_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Meat")){
                    item_thumbnail_url = "beef_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Paratha")){
                    item_thumbnail_url = "paratha_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Samosa")){
                    item_thumbnail_url = "samosa_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Spring Rolls")){
                    item_thumbnail_url = "spring_roll_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Seafood")){
                    item_thumbnail_url = "sea_food_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Beef Burgers")){
                    item_thumbnail_url = "beef_burgers_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Lamb")){
                    item_thumbnail_url = "lamb_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Gravy")){
                    item_thumbnail_url = "gravy_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Pasta")){
                    item_thumbnail_url = "pasta_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Vegetables")){
                    item_thumbnail_url = "vegetables_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Milk")){
					item_thumbnail_url = "canned_milk_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Oil")){
					item_thumbnail_url = "canned_oil_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Coconut Milk")){
					item_thumbnail_url = "canned_coconut_milk_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Fish")){
					item_thumbnail_url = "canned_fish_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Juice")){
					item_thumbnail_url = "canned_juice_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Beans")){
					item_thumbnail_url = "canned_beans_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Maize")){
					item_thumbnail_url = "canned_maize_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Canned Fish 2")){
					item_thumbnail_url = "canned_fish_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Cooking Oil")){
					item_thumbnail_url = "cooking_oil_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Cooking Fat")){
					item_thumbnail_url = "cooking_fat_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Sweets")){
					item_thumbnail_url = "sweets_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Biscuits")){
					item_thumbnail_url = "biscuits_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Chocolate Confectionary")){
					item_thumbnail_url = "chocolate_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Chewing Gum")){
					item_thumbnail_url = "chewing_gum_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Lollipop")){
					item_thumbnail_url = "lollipop_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Bitez")){
					item_thumbnail_url = "bitez_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Glucose")){
					item_thumbnail_url = "glucose_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Pop-corn")){
					item_thumbnail_url = "pop_corn_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Toffee")){
					item_thumbnail_url = "toffee_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Peanuts")){
					item_thumbnail_url = "peanuts_icon";
				}else if(SELECTED_PRODUCT_TITLE.equals("Candles")){
					item_thumbnail_url = "candles_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Air Freshner")){
                    item_thumbnail_url = "air_freshner_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Dishes & Scouring")){
                    item_thumbnail_url = "dishes_scouring_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Powdered Detergent")){
                    item_thumbnail_url = "powdered_detergent_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Bar Soap")){
                    item_thumbnail_url = "bar_soap_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Liquid Soap")){
                    item_thumbnail_url = "liquid_soap_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Battery")){
                    item_thumbnail_url = "battery_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Insect Aeresol")){
                    item_thumbnail_url = "insect_aerosol_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Matches")){
                    item_thumbnail_url = "matches_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Bleach")){
                    item_thumbnail_url = "bleach_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Handwash")){
                    item_thumbnail_url = "handwash_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Antiseptic Liquid")){
                    item_thumbnail_url = "antiseptic_liquid";
                }else if(SELECTED_PRODUCT_TITLE.equals("Toilet Cleaner Liquid")){
                    item_thumbnail_url = "toilet_cleaner_liquid";
                }else if(SELECTED_PRODUCT_TITLE.equals("Steel Wool")){
                    item_thumbnail_url = "steel_wool_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Scrubber")){
                    item_thumbnail_url = "scrubber_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Bulb")){
                    item_thumbnail_url = "bulb_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Polish")){
                    item_thumbnail_url = "polish_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Glue")){
                    item_thumbnail_url = "glue_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Stove Wick")){
                    item_thumbnail_url = "stove_wick_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Papersbags")){
                    item_thumbnail_url = "paperbags_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Fabric Softner")){
                    item_thumbnail_url = "fabric_softner";
                }else if(SELECTED_PRODUCT_TITLE.equals("Insect Repellant")){
                    item_thumbnail_url = "insect_repellant_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Seasoning")){
                    item_thumbnail_url = "seasoning_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Salt")){
                    item_thumbnail_url = "salt_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Pilau Masala")){
                    item_thumbnail_url = "pilau_masala_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Tea Masala")){
                    item_thumbnail_url = "tea_masala_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Sugar")){
                    item_thumbnail_url = "sugar_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Rice")){
                    item_thumbnail_url = "rice_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Cereals")){
                    item_thumbnail_url = "cereals_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Green Grams(ndengu)")){
                    item_thumbnail_url = "green_grams_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Oats")){
                    item_thumbnail_url = "oats_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Popcorn")){
                    item_thumbnail_url = "popcorn_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Honey")){
                    item_thumbnail_url = "honey_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Sauces")){
                    item_thumbnail_url = "sauces_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Margarine Spread")){
                    item_thumbnail_url = "margarine_spread_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Soya")){
                    item_thumbnail_url = "soya_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Spread")){
                    item_thumbnail_url = "spread_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Mayonnaise")){
                    item_thumbnail_url = "mayonnaise_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Noodles")){
                    item_thumbnail_url = "noodles_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Body Soap")){
                    item_thumbnail_url = "body_soap_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Toothpaste")){
                    item_thumbnail_url = "tooth_paste_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Tooth Brush")){
                    item_thumbnail_url = "tooth_brush_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Shoe Care")){
                    item_thumbnail_url = "shoe_care_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Perfumes")){
                    item_thumbnail_url = "perfumes_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Roll On")){
                    item_thumbnail_url = "roll_on_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Shampoo")){
                    item_thumbnail_url = "shampoo_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Tissue Paper")){
                    item_thumbnail_url = "tissue_paper_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Lotion & Creams")){
                    item_thumbnail_url = "lotions_and_cream_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Hair Care")){
                    item_thumbnail_url = "hair_care_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Lady Essentials")){
                    item_thumbnail_url = "lady_essentials_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Razors")){
                    item_thumbnail_url = "razors_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Wipes")){
                    item_thumbnail_url = "wipes_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Scrub")){
                    item_thumbnail_url = "scrub_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Dye")){
                    item_thumbnail_url = "dye_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Shower Gel")){
                    item_thumbnail_url = "shower_gel_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Serviettes")){
                    item_thumbnail_url = "serviettes_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Tooth Picks")){
                    item_thumbnail_url = "tooth_picks_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Cotton Wool")){
                    item_thumbnail_url = "cotton_wool_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Deli")){
                    item_thumbnail_url = "deli_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Meat")){
                    item_thumbnail_url = "beef_icon";
                }else if(SELECTED_PRODUCT_TITLE.equals("Medicare")){
                    item_thumbnail_url = "medicare_icon";
                }



                d.setId(item_id);
				d.setTitle(item_title);
				d.setSize(item_size);
				d.setPrice(item_price);


                  d.setThumbnailUrl(item_thumbnail_url);
				// d.setThumbnailUrl(item_thumbnail_url);
				d.setFronthumbnailUrl(Constants.IMAGES_URL
						+ item_front_thumbnail_url);
                d.setBackThumbnailUrl(Constants.IMAGES_URL
                        + item_back_thumbnail_url);
                d.setTopThumbnailUrl(Constants.IMAGES_URL
                        + item__top_thumbnail_url);
                d.setItem_description(item__description);
				d.setUnits(item_units_in_cart);

				d.item_id = item_id;
				d.item_title = item_title;
				d.item_price = item_price;
				d.item_size = item_size;

                Log.d("item_thumbnail_url", " --> " + item_thumbnail_url);

                String imageUri = "mipmap://R.mipmap." + item_thumbnail_url;

                d.item_thumbnail_url = item_thumbnail_url;

                Log.d("imageUri", " --> " + d.item_thumbnail_url);

				//d.item_thumbnail_url = Constants.IMAGES_URL + item_thumbnail_url;
            //    d.item_thumbnail_url = "mipmap://R.mipmap.grocery_baking.png";
                d.item_front_thumbnail_url = Constants.IMAGES_URL
                        + item_front_thumbnail_url;
                d.item_back_thumbnail_url = Constants.IMAGES_URL
                        + item_back_thumbnail_url;
                d.item__top_thumbnail_url = Constants.IMAGES_URL
                        + item__top_thumbnail_url;
                d.item_description = item__description;

				Log.d("item__description ", " --> " + item__description);

				d.item_units_in_cart = item_units_in_cart;

				PRODUCTSBRANDSLIST.add(d);

				k++;
				resultsProductsCursor.moveToNext();
			}

		}

	}

	public void showDialogEmptyTrolley(final String message) throws Exception {
		AlertDialog.Builder builder = new AlertDialog.Builder(
				ActivityStep07ListProducts.this);
		builder.setMessage("You will lose all the items that you have selected. "
				+ message);

		builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// Clear Cart Session
				sharedPreferences.edit().remove("myTrolley").commit();

				Intent intent = new Intent(ActivityStep07ListProducts.this,
						ActivityStep05ListAisles.class);
				startActivity(intent);

				// Go back to previous page
				// finish();
				dialog.dismiss();
			}
		});

		builder.setNegativeButton("Cancel",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});

		builder.show();
	}

}
